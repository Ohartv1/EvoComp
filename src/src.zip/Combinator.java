
public interface Combinator {

	public Tuple combine(Tuple a, Tuple b);
	
}
