
public class CombinationMethod1 implements Combinator{


	public Tuple combine(Tuple a, Tuple b) {
		Tuple combination = new Tuple();
		
		// doe iets slims met a en b
		
		return combination;
	}

	
	
}
